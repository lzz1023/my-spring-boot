package org.spring.springboot.web;

import org.junit.Test;

/**
 * Spring Boot ErrorJsonController 测试 - {@link ErrorJsonController}
 *
 * Created by bysocket on 16/4/26.
 */
public class ErrorJsonControllerTest {

    @Test
    public void testSayHello() {
    }
}
